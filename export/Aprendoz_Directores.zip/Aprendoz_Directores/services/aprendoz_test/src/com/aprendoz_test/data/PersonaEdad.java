
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PersonaEdad
 *  03/27/2014 12:15:22
 * 
 */
public class PersonaEdad {

    private PersonaEdadId id;

    public PersonaEdad() {
    }

    public PersonaEdad(PersonaEdadId id) {
        this.id = id;
    }

    public PersonaEdadId getId() {
        return id;
    }

    public void setId(PersonaEdadId id) {
        this.id = id;
    }

}
