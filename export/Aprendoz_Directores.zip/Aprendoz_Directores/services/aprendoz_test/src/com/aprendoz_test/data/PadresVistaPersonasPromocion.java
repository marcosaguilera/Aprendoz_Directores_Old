
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaPersonasPromocion
 *  03/27/2014 12:15:22
 * 
 */
public class PadresVistaPersonasPromocion {

    private PadresVistaPersonasPromocionId id;

    public PadresVistaPersonasPromocion() {
    }

    public PadresVistaPersonasPromocion(PadresVistaPersonasPromocionId id) {
        this.id = id;
    }

    public PadresVistaPersonasPromocionId getId() {
        return id;
    }

    public void setId(PadresVistaPersonasPromocionId id) {
        this.id = id;
    }

}
