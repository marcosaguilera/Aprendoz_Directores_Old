
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaInscAlumAsig
 *  03/27/2014 12:15:22
 * 
 */
public class AdministracionVistaInscAlumAsig {

    private AdministracionVistaInscAlumAsigId id;

    public AdministracionVistaInscAlumAsig() {
    }

    public AdministracionVistaInscAlumAsig(AdministracionVistaInscAlumAsigId id) {
        this.id = id;
    }

    public AdministracionVistaInscAlumAsigId getId() {
        return id;
    }

    public void setId(AdministracionVistaInscAlumAsigId id) {
        this.id = id;
    }

}
