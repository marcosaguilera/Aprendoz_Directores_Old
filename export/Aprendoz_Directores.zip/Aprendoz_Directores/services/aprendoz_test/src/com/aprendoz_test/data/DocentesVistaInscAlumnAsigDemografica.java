
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaInscAlumnAsigDemografica
 *  03/27/2014 12:15:22
 * 
 */
public class DocentesVistaInscAlumnAsigDemografica {

    private DocentesVistaInscAlumnAsigDemograficaId id;

    public DocentesVistaInscAlumnAsigDemografica() {
    }

    public DocentesVistaInscAlumnAsigDemografica(DocentesVistaInscAlumnAsigDemograficaId id) {
        this.id = id;
    }

    public DocentesVistaInscAlumnAsigDemograficaId getId() {
        return id;
    }

    public void setId(DocentesVistaInscAlumnAsigDemograficaId id) {
        this.id = id;
    }

}
