
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesInscCursoAsignatura
 *  03/27/2014 12:15:22
 * 
 */
public class DocentesInscCursoAsignatura {

    private DocentesInscCursoAsignaturaId id;

    public DocentesInscCursoAsignatura() {
    }

    public DocentesInscCursoAsignatura(DocentesInscCursoAsignaturaId id) {
        this.id = id;
    }

    public DocentesInscCursoAsignaturaId getId() {
        return id;
    }

    public void setId(DocentesInscCursoAsignaturaId id) {
        this.id = id;
    }

}
