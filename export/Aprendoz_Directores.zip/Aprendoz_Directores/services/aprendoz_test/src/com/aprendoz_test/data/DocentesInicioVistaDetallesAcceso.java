
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesInicioVistaDetallesAcceso
 *  03/27/2014 12:15:22
 * 
 */
public class DocentesInicioVistaDetallesAcceso {

    private DocentesInicioVistaDetallesAccesoId id;

    public DocentesInicioVistaDetallesAcceso() {
    }

    public DocentesInicioVistaDetallesAcceso(DocentesInicioVistaDetallesAccesoId id) {
        this.id = id;
    }

    public DocentesInicioVistaDetallesAccesoId getId() {
        return id;
    }

    public void setId(DocentesInicioVistaDetallesAccesoId id) {
        this.id = id;
    }

}
