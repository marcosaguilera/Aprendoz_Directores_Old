
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaInscAlumnCurso
 *  03/27/2014 12:15:23
 * 
 */
public class AdministracionVistaInscAlumnCurso {

    private AdministracionVistaInscAlumnCursoId id;

    public AdministracionVistaInscAlumnCurso() {
    }

    public AdministracionVistaInscAlumnCurso(AdministracionVistaInscAlumnCursoId id) {
        this.id = id;
    }

    public AdministracionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(AdministracionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
