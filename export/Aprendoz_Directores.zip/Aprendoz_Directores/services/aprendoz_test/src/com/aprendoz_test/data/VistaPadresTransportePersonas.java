
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VistaPadresTransportePersonas
 *  05/27/2013 16:56:29
 * 
 */
public class VistaPadresTransportePersonas {

    private VistaPadresTransportePersonasId id;

    public VistaPadresTransportePersonas() {
    }

    public VistaPadresTransportePersonas(VistaPadresTransportePersonasId id) {
        this.id = id;
    }

    public VistaPadresTransportePersonasId getId() {
        return id;
    }

    public void setId(VistaPadresTransportePersonasId id) {
        this.id = id;
    }

}
