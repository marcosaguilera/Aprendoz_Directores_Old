
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaCalificacionFinal
 *  03/27/2014 12:15:22
 * 
 */
public class DocentesVistaCalificacionFinal {

    private DocentesVistaCalificacionFinalId id;

    public DocentesVistaCalificacionFinal() {
    }

    public DocentesVistaCalificacionFinal(DocentesVistaCalificacionFinalId id) {
        this.id = id;
    }

    public DocentesVistaCalificacionFinalId getId() {
        return id;
    }

    public void setId(DocentesVistaCalificacionFinalId id) {
        this.id = id;
    }

}
