
package com.aprendoz_test.data;



/**
 *  aprendoz_test.CalifEstCopy
 *  03/27/2014 12:15:23
 * 
 */
public class CalifEstCopy {

    private CalifEstCopyId id;

    public CalifEstCopy() {
    }

    public CalifEstCopy(CalifEstCopyId id) {
        this.id = id;
    }

    public CalifEstCopyId getId() {
        return id;
    }

    public void setId(CalifEstCopyId id) {
        this.id = id;
    }

}
