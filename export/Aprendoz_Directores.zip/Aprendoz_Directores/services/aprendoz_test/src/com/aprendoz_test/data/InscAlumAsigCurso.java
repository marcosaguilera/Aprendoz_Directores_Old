
package com.aprendoz_test.data;



/**
 *  aprendoz_test.InscAlumAsigCurso
 *  03/27/2014 12:15:23
 * 
 */
public class InscAlumAsigCurso {

    private InscAlumAsigCursoId id;

    public InscAlumAsigCurso() {
    }

    public InscAlumAsigCurso(InscAlumAsigCursoId id) {
        this.id = id;
    }

    public InscAlumAsigCursoId getId() {
        return id;
    }

    public void setId(InscAlumAsigCursoId id) {
        this.id = id;
    }

}
