
package com.aprendoz_test.data;



/**
 *  aprendoz_test.ImportacionExtracto
 *  03/27/2014 12:15:22
 * 
 */
public class ImportacionExtracto {

    private ImportacionExtractoId id;

    public ImportacionExtracto() {
    }

    public ImportacionExtracto(ImportacionExtractoId id) {
        this.id = id;
    }

    public ImportacionExtractoId getId() {
        return id;
    }

    public void setId(ImportacionExtractoId id) {
        this.id = id;
    }

}
