
package com.aprendoz_test.data;



/**
 *  aprendoz_test.TmpEnrLog
 *  03/27/2014 12:15:22
 * 
 */
public class TmpEnrLog {

    private TmpEnrLogId id;

    public TmpEnrLog() {
    }

    public TmpEnrLog(TmpEnrLogId id) {
        this.id = id;
    }

    public TmpEnrLogId getId() {
        return id;
    }

    public void setId(TmpEnrLogId id) {
        this.id = id;
    }

}
