
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VistaDashboardAvanzadosYMagistrales
 *  03/27/2014 12:15:22
 * 
 */
public class VistaDashboardAvanzadosYMagistrales {

    private VistaDashboardAvanzadosYMagistralesId id;

    public VistaDashboardAvanzadosYMagistrales() {
    }

    public VistaDashboardAvanzadosYMagistrales(VistaDashboardAvanzadosYMagistralesId id) {
        this.id = id;
    }

    public VistaDashboardAvanzadosYMagistralesId getId() {
        return id;
    }

    public void setId(VistaDashboardAvanzadosYMagistralesId id) {
        this.id = id;
    }

}
