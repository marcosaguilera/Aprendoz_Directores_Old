
package com.aprendoz_test.data.output;



/**
 * Generated for query "complexSendMail" on 03/27/2014 12:15:38
 * 
 */
public class ComplexSendMailRtnType {

    private Integer ide;
    private Integer idalumno;
    private String nombreAlumno;

    public ComplexSendMailRtnType() {
    }

    public ComplexSendMailRtnType(Integer ide, Integer idalumno, String nombreAlumno) {
        this.ide = ide;
        this.idalumno = idalumno;
        this.nombreAlumno = nombreAlumno;
    }

    public Integer getIde() {
        return ide;
    }

    public void setIde(Integer ide) {
        this.ide = ide;
    }

    public Integer getIdalumno() {
        return idalumno;
    }

    public void setIdalumno(Integer idalumno) {
        this.idalumno = idalumno;
    }

    public String getNombreAlumno() {
        return nombreAlumno;
    }

    public void setNombreAlumno(String nombreAlumno) {
        this.nombreAlumno = nombreAlumno;
    }

}
