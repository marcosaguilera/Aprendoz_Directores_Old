
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaDristribucionAlumnosCursos
 *  03/27/2014 12:15:22
 * 
 */
public class DocentesVistaDristribucionAlumnosCursos {

    private DocentesVistaDristribucionAlumnosCursosId id;

    public DocentesVistaDristribucionAlumnosCursos() {
    }

    public DocentesVistaDristribucionAlumnosCursos(DocentesVistaDristribucionAlumnosCursosId id) {
        this.id = id;
    }

    public DocentesVistaDristribucionAlumnosCursosId getId() {
        return id;
    }

    public void setId(DocentesVistaDristribucionAlumnosCursosId id) {
        this.id = id;
    }

}
