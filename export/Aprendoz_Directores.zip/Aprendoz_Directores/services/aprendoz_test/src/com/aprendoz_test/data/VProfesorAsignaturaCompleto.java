
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VProfesorAsignaturaCompleto
 *  03/27/2014 12:15:22
 * 
 */
public class VProfesorAsignaturaCompleto {

    private VProfesorAsignaturaCompletoId id;

    public VProfesorAsignaturaCompleto() {
    }

    public VProfesorAsignaturaCompleto(VProfesorAsignaturaCompletoId id) {
        this.id = id;
    }

    public VProfesorAsignaturaCompletoId getId() {
        return id;
    }

    public void setId(VProfesorAsignaturaCompletoId id) {
        this.id = id;
    }

}
