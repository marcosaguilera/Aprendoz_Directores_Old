
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VistaEnvioCorreo
 *  03/27/2014 12:15:23
 * 
 */
public class VistaEnvioCorreo {

    private VistaEnvioCorreoId id;

    public VistaEnvioCorreo() {
    }

    public VistaEnvioCorreo(VistaEnvioCorreoId id) {
        this.id = id;
    }

    public VistaEnvioCorreoId getId() {
        return id;
    }

    public void setId(VistaEnvioCorreoId id) {
        this.id = id;
    }

}
