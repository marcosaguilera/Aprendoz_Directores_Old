
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VistaAlumnosActivosPrejardinNuevos
 *  03/27/2014 12:15:22
 * 
 */
public class VistaAlumnosActivosPrejardinNuevos {

    private VistaAlumnosActivosPrejardinNuevosId id;

    public VistaAlumnosActivosPrejardinNuevos() {
    }

    public VistaAlumnosActivosPrejardinNuevos(VistaAlumnosActivosPrejardinNuevosId id) {
        this.id = id;
    }

    public VistaAlumnosActivosPrejardinNuevosId getId() {
        return id;
    }

    public void setId(VistaAlumnosActivosPrejardinNuevosId id) {
        this.id = id;
    }

}
