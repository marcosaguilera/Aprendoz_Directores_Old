
package com.aprendoz_test.data;



/**
 *  aprendoz_test.ServiciosListadoServiciosAlumnos
 *  03/27/2014 12:15:23
 * 
 */
public class ServiciosListadoServiciosAlumnos {

    private ServiciosListadoServiciosAlumnosId id;

    public ServiciosListadoServiciosAlumnos() {
    }

    public ServiciosListadoServiciosAlumnos(ServiciosListadoServiciosAlumnosId id) {
        this.id = id;
    }

    public ServiciosListadoServiciosAlumnosId getId() {
        return id;
    }

    public void setId(ServiciosListadoServiciosAlumnosId id) {
        this.id = id;
    }

}
