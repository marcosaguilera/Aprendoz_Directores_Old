
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VProfesorAsignatura
 *  03/27/2014 12:15:23
 * 
 */
public class VProfesorAsignatura {

    private VProfesorAsignaturaId id;

    public VProfesorAsignatura() {
    }

    public VProfesorAsignatura(VProfesorAsignaturaId id) {
        this.id = id;
    }

    public VProfesorAsignaturaId getId() {
        return id;
    }

    public void setId(VProfesorAsignaturaId id) {
        this.id = id;
    }

}
