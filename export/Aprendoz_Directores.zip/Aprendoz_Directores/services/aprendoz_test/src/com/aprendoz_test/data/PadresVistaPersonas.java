
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaPersonas
 *  03/27/2014 12:15:22
 * 
 */
public class PadresVistaPersonas {

    private PadresVistaPersonasId id;

    public PadresVistaPersonas() {
    }

    public PadresVistaPersonas(PadresVistaPersonasId id) {
        this.id = id;
    }

    public PadresVistaPersonasId getId() {
        return id;
    }

    public void setId(PadresVistaPersonasId id) {
        this.id = id;
    }

}
