
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaAprendizajesAsignatura
 *  03/27/2014 12:15:23
 * 
 */
public class DocentesVistaAprendizajesAsignatura {

    private DocentesVistaAprendizajesAsignaturaId id;

    public DocentesVistaAprendizajesAsignatura() {
    }

    public DocentesVistaAprendizajesAsignatura(DocentesVistaAprendizajesAsignaturaId id) {
        this.id = id;
    }

    public DocentesVistaAprendizajesAsignaturaId getId() {
        return id;
    }

    public void setId(DocentesVistaAprendizajesAsignaturaId id) {
        this.id = id;
    }

}
