
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaAsignaturas
 *  03/27/2014 12:15:22
 * 
 */
public class DocentesVistaAsignaturas {

    private DocentesVistaAsignaturasId id;

    public DocentesVistaAsignaturas() {
    }

    public DocentesVistaAsignaturas(DocentesVistaAsignaturasId id) {
        this.id = id;
    }

    public DocentesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(DocentesVistaAsignaturasId id) {
        this.id = id;
    }

}
