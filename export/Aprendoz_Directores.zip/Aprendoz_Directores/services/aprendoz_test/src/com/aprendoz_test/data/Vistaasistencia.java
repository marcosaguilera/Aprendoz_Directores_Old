
package com.aprendoz_test.data;



/**
 *  aprendoz_test.Vistaasistencia
 *  03/27/2014 12:15:23
 * 
 */
public class Vistaasistencia {

    private VistaasistenciaId id;

    public Vistaasistencia() {
    }

    public Vistaasistencia(VistaasistenciaId id) {
        this.id = id;
    }

    public VistaasistenciaId getId() {
        return id;
    }

    public void setId(VistaasistenciaId id) {
        this.id = id;
    }

}
