
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaPersonasDemografica
 *  03/27/2014 12:15:22
 * 
 */
public class DocentesVistaPersonasDemografica {

    private DocentesVistaPersonasDemograficaId id;

    public DocentesVistaPersonasDemografica() {
    }

    public DocentesVistaPersonasDemografica(DocentesVistaPersonasDemograficaId id) {
        this.id = id;
    }

    public DocentesVistaPersonasDemograficaId getId() {
        return id;
    }

    public void setId(DocentesVistaPersonasDemograficaId id) {
        this.id = id;
    }

}
