
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AprEsperados
 *  03/27/2014 12:15:23
 * 
 */
public class AprEsperados {

    private AprEsperadosId id;

    public AprEsperados() {
    }

    public AprEsperados(AprEsperadosId id) {
        this.id = id;
    }

    public AprEsperadosId getId() {
        return id;
    }

    public void setId(AprEsperadosId id) {
        this.id = id;
    }

}
