
package com.aprendoz_test.data;



/**
 *  aprendoz_test.FacturacionSapiens
 *  03/27/2014 12:15:22
 * 
 */
public class FacturacionSapiens {

    private FacturacionSapiensId id;

    public FacturacionSapiens() {
    }

    public FacturacionSapiens(FacturacionSapiensId id) {
        this.id = id;
    }

    public FacturacionSapiensId getId() {
        return id;
    }

    public void setId(FacturacionSapiensId id) {
        this.id = id;
    }

}
