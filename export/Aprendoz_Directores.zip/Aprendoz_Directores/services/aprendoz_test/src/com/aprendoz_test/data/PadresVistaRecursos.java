
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaRecursos
 *  03/27/2014 12:15:22
 * 
 */
public class PadresVistaRecursos {

    private PadresVistaRecursosId id;

    public PadresVistaRecursos() {
    }

    public PadresVistaRecursos(PadresVistaRecursosId id) {
        this.id = id;
    }

    public PadresVistaRecursosId getId() {
        return id;
    }

    public void setId(PadresVistaRecursosId id) {
        this.id = id;
    }

}
