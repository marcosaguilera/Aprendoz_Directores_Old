
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DirectoresDocentesListadoReportes
 *  03/27/2014 12:15:23
 * 
 */
public class DirectoresDocentesListadoReportes {

    private DirectoresDocentesListadoReportesId id;

    public DirectoresDocentesListadoReportes() {
    }

    public DirectoresDocentesListadoReportes(DirectoresDocentesListadoReportesId id) {
        this.id = id;
    }

    public DirectoresDocentesListadoReportesId getId() {
        return id;
    }

    public void setId(DirectoresDocentesListadoReportesId id) {
        this.id = id;
    }

}
