
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VistaEventualidadesNotificaciones
 *  03/27/2014 12:15:23
 * 
 */
public class VistaEventualidadesNotificaciones {

    private VistaEventualidadesNotificacionesId id;

    public VistaEventualidadesNotificaciones() {
    }

    public VistaEventualidadesNotificaciones(VistaEventualidadesNotificacionesId id) {
        this.id = id;
    }

    public VistaEventualidadesNotificacionesId getId() {
        return id;
    }

    public void setId(VistaEventualidadesNotificacionesId id) {
        this.id = id;
    }

}
