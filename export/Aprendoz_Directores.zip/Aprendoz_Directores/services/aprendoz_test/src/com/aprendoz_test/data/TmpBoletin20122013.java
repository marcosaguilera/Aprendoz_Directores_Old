
package com.aprendoz_test.data;



/**
 *  aprendoz_test.TmpBoletin20122013
 *  03/27/2014 12:15:23
 * 
 */
public class TmpBoletin20122013 {

    private TmpBoletin20122013Id id;

    public TmpBoletin20122013() {
    }

    public TmpBoletin20122013(TmpBoletin20122013Id id) {
        this.id = id;
    }

    public TmpBoletin20122013Id getId() {
        return id;
    }

    public void setId(TmpBoletin20122013Id id) {
        this.id = id;
    }

}
