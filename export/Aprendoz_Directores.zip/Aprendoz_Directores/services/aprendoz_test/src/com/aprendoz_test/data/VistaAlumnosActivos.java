
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VistaAlumnosActivos
 *  03/27/2014 12:15:22
 * 
 */
public class VistaAlumnosActivos {

    private VistaAlumnosActivosId id;

    public VistaAlumnosActivos() {
    }

    public VistaAlumnosActivos(VistaAlumnosActivosId id) {
        this.id = id;
    }

    public VistaAlumnosActivosId getId() {
        return id;
    }

    public void setId(VistaAlumnosActivosId id) {
        this.id = id;
    }

}
